import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import crypto from 'node:crypto';
import { createClient } from '@supabase/supabase-js';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const PRICE = Number(process.env.PRODUCT_PRICE || '19.90');
const APP_BASE_URL = (process.env.APP_BASE_URL || '').replace(/\/$/, '');
const paymentsEnabled = process.env.PAYMENTS_ENABLED === 'true';

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: 'draft-8', legacyHeaders: false }));
app.use(express.static('public', { extensions: ['html'] }));

const required = ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY'];
const missing = required.filter((key) => !process.env[key]);
let supabase = null;
if (missing.length === 0) {
  supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}

function requireConfigured(req, res, next) {
  if (missing.length) return res.status(503).json({ error: 'Servidor não configurado. Confira as variáveis de ambiente.' });
  next();
}

async function authenticatedUser(req, res, next) {
  const header = req.get('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Faça login para continuar.' });
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user) return res.status(401).json({ error: 'Sessão inválida ou expirada.' });
  req.user = data.user;
  next();
}

app.get('/api/health', (_req, res) => res.json({ ok: true, paymentsEnabled, configured: missing.length === 0 }));

// Only these values are public. Never return service-role keys or Mercado Pago secrets.
app.get('/api/config', (_req, res) => {
  res.json({ supabaseUrl: process.env.SUPABASE_URL || '', supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '', productPrice: PRICE });
});

app.post('/api/orders', requireConfigured, authenticatedUser, async (req, res) => {
  if (!paymentsEnabled) return res.status(503).json({ error: 'Pagamentos estão desligados até a configuração segura do provedor.' });
  if (!process.env.MERCADOPAGO_ACCESS_TOKEN || !process.env.MERCADOPAGO_WEBHOOK_SECRET || !APP_BASE_URL.startsWith('https://')) {
    return res.status(503).json({ error: 'Configure credenciais e URL HTTPS antes de habilitar pagamentos.' });
  }
  const idempotencyKey = String(req.body?.idempotencyKey || '');
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(idempotencyKey)) {
    return res.status(400).json({ error: 'Chave de pedido inválida. Tente novamente.' });
  }

  // A repeated request with the same key reuses the same order/payment.
  let { data: order, error: findError } = await supabase.from('orders')
    .select('*').eq('user_id', req.user.id).eq('idempotency_key', idempotencyKey).maybeSingle();
  if (findError) return res.status(500).json({ error: 'Não foi possível consultar o pedido.' });
  if (order?.status === 'paid') return res.json({ orderId: order.id, status: 'paid' });
  if (order?.mp_payment_id && order?.pix_copy_paste) {
    return res.json({ orderId: order.id, status: order.status, pixCopyPaste: order.pix_copy_paste, qrBase64: order.pix_qr_base64, ticketUrl: order.ticket_url });
  }

  if (!order) {
    const { data, error } = await supabase.from('orders').insert({
      user_id: req.user.id, idempotency_key: idempotencyKey, amount: PRICE, currency: 'BRL', status: 'pending'
    }).select('*').single();
    if (error) return res.status(500).json({ error: 'Não foi possível criar o pedido.' });
    order = data;
  }

  try {
    const response = await fetch('https://api.mercadopago.com/v1/payments', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.MERCADOPAGO_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
        'X-Idempotency-Key': order.id
      },
      body: JSON.stringify({
        transaction_amount: Number(order.amount),
        description: 'Acesso ao Renda na Prática',
        payment_method_id: 'pix',
        external_reference: order.id,
        notification_url: `${APP_BASE_URL}/api/webhooks/mercadopago`,
        payer: { email: req.user.email }
      })
    });
    const payment = await response.json();
    if (!response.ok) {
      console.error('Erro ao criar pagamento no Mercado Pago:', response.status, payment?.message || 'sem detalhes');
      return res.status(502).json({ error: 'O provedor não conseguiu criar a cobrança. Tente novamente.' });
    }
    const pix = payment?.point_of_interaction?.transaction_data || {};
    const { error: updateError } = await supabase.from('orders').update({
      mp_payment_id: String(payment.id),
      pix_copy_paste: pix.qr_code || null,
      pix_qr_base64: pix.qr_code_base64 || null,
      ticket_url: pix.ticket_url || null,
      updated_at: new Date().toISOString()
    }).eq('id', order.id).eq('user_id', req.user.id);
    if (updateError) {
      console.error('Não foi possível salvar os dados de pagamento do pedido', order.id);
      return res.status(500).json({ error: 'Cobrança criada, mas não foi possível salvar os dados. Contate o suporte antes de tentar novamente.' });
    }
    return res.status(201).json({ orderId: order.id, status: payment.status || 'pending', pixCopyPaste: pix.qr_code, qrBase64: pix.qr_code_base64, ticketUrl: pix.ticket_url });
  } catch (error) {
    console.error('Falha ao criar pagamento:', error.message);
    return res.status(502).json({ error: 'Falha de comunicação com o provedor de pagamentos.' });
  }
});

app.get('/api/orders/:id', requireConfigured, authenticatedUser, async (req, res) => {
  const { data, error } = await supabase.from('orders').select('id,status,amount,currency,created_at')
    .eq('id', req.params.id).eq('user_id', req.user.id).maybeSingle();
  if (error) return res.status(500).json({ error: 'Não foi possível consultar o pedido.' });
  if (!data) return res.status(404).json({ error: 'Pedido não encontrado.' });
  res.json(data);
});

app.get('/api/access', requireConfigured, authenticatedUser, async (req, res) => {
  const { data, error } = await supabase.from('orders').select('id,access_granted_at,created_at')
    .eq('user_id', req.user.id).eq('status', 'paid').order('access_granted_at', { ascending: false }).limit(1).maybeSingle();
  if (error) return res.status(500).json({ error: 'Não foi possível verificar o acesso.' });
  res.json({ hasAccess: Boolean(data), order: data || null });
});

app.get('/api/product-content', requireConfigured, authenticatedUser, async (req, res) => {
  const { data, error } = await supabase.from('orders').select('id')
    .eq('user_id', req.user.id).eq('status', 'paid').limit(1).maybeSingle();
  if (error) return res.status(500).json({ error: 'Não foi possível verificar a compra.' });
  if (!data) return res.status(403).json({ error: 'Acesso liberado somente após confirmação do pagamento.' });

  // Substitua este conteúdo inicial pelo app/guia final antes de vender.
  res.json({ title: 'Renda na Prática', sections: [
    { title: 'Comece com uma habilidade', body: 'Escolha algo que você já consegue fazer ou aprender: edição de vídeos, design simples, criação de sites ou escrita.' },
    { title: 'Monte um pequeno portfólio', body: 'Crie 2 ou 3 exemplos próprios e mostre claramente o que você entrega.' },
    { title: 'Divulgue com honestidade', body: 'Explique o serviço, o prazo e o preço. Não prometa ganhos garantidos e desconfie de esquemas que pedem dinheiro para liberar trabalho.' },
    { title: 'Organize seu progresso', body: 'Anote tarefas, contatos, custos e resultados. Peça orientação a um responsável para contratos, pagamentos e contas de plataformas.' }
  ] });
});

function parseSignature(header = '') {
  const parts = Object.fromEntries(header.split(',').map(part => {
    const i = part.indexOf('=');
    return i < 0 ? ['', ''] : [part.slice(0, i).trim(), part.slice(i + 1).trim()];
  }));
  return { ts: parts.ts, v1: parts.v1 };
}

function validWebhookSignature(req, paymentId) {
  const secret = process.env.MERCADOPAGO_WEBHOOK_SECRET;
  const requestId = req.get('x-request-id');
  const { ts, v1 } = parseSignature(req.get('x-signature'));
  if (!secret || !requestId || !ts || !v1 || !paymentId) return false;
  // Mercado Pago manifest for payment notifications: id, request-id, timestamp.
  const manifest = `id:${String(paymentId).toLowerCase()};request-id:${requestId};ts:${ts};`;
  const expected = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
  try {
    const a = Buffer.from(expected, 'hex');
    const b = Buffer.from(v1, 'hex');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch { return false; }
}

app.post('/api/webhooks/mercadopago', requireConfigured, async (req, res) => {
  const type = String(req.query.type || req.body?.type || '');
  const paymentId = String(req.query['data.id'] || req.body?.data?.id || '');
  if (type !== 'payment' || !paymentId) return res.sendStatus(200);
  if (!validWebhookSignature(req, paymentId)) return res.status(401).json({ error: 'Assinatura de webhook inválida.' });

  try {
    const response = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`, {
      headers: { Authorization: `Bearer ${process.env.MERCADOPAGO_ACCESS_TOKEN}` }
    });
    const payment = await response.json();
    if (!response.ok) return res.sendStatus(502);

    // Never trust webhook body alone. Verify the payment by querying Mercado Pago.
    if (payment.status !== 'approved') return res.sendStatus(200);
    if (payment.payment_method_id !== 'pix' || payment.currency_id !== 'BRL') return res.sendStatus(200);
    const orderId = String(payment.external_reference || '');
    if (!/^[0-9a-f-]{36}$/i.test(orderId)) return res.sendStatus(200);

    const { data: order, error: orderError } = await supabase.from('orders').select('id,status,amount,currency')
      .eq('id', orderId).maybeSingle();
    if (orderError) return res.sendStatus(500);
    if (!order || Number(payment.transaction_amount) !== Number(order.amount) || payment.currency_id !== order.currency) return res.sendStatus(200);

    // Idempotent update: repeated Webhooks do not grant multiple entitlements.
    const { error: updateError } = await supabase.from('orders').update({
      status: 'paid', access_granted_at: new Date().toISOString(), mp_payment_id: String(payment.id), updated_at: new Date().toISOString()
    }).eq('id', order.id).neq('status', 'paid');
    if (updateError) return res.sendStatus(500);
    return res.sendStatus(200);
  } catch (error) {
    console.error('Falha ao processar notificação de pagamento:', error.message);
    return res.sendStatus(500);
  }
});

app.use((err, _req, res, _next) => {
  console.error('Erro inesperado na requisição:', err.message);
  res.status(500).json({ error: 'Erro interno. Tente novamente.' });
});

app.listen(PORT, () => console.log(`Renda na Prática iniciado na porta ${PORT}. Pagamentos habilitados: ${paymentsEnabled}`));
