-- Execute no SQL Editor do seu projeto Supabase.
create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  idempotency_key uuid not null,
  status text not null default 'pending' check (status in ('pending','paid','failed')),
  amount numeric(10,2) not null check (amount > 0),
  currency text not null default 'BRL' check (currency = 'BRL'),
  mp_payment_id text unique,
  pix_copy_paste text,
  pix_qr_base64 text,
  ticket_url text,
  access_granted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, idempotency_key)
);

create index if not exists orders_user_status_idx on public.orders(user_id, status);

-- Webhook retries are normal; this table records event IDs for observability/deduplication.
create table if not exists public.webhook_events (
  id text primary key,
  event_type text,
  received_at timestamptz not null default now()
);

alter table public.orders enable row level security;
alter table public.webhook_events enable row level security;

-- No client-side INSERT/UPDATE/DELETE policies. Only the server's service-role key
-- can mutate orders. The app reads order status through the authenticated server API.
-- Keep webhook_events inaccessible to normal clients.
revoke all on public.orders from anon, authenticated;
revoke all on public.webhook_events from anon, authenticated;
