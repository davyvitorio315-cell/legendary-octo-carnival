# Renda na Prática — projeto integrado

Este projeto reúne o site de vendas, a apresentação das trilhas de aprendizagem, as perguntas frequentes, o cadastro e login, o pagamento por Pix e a área exclusiva do aplicativo.

## Situação atual

- Página pública responsiva em português, com apresentação do produto, cadastro/login, fluxo de Pix e área exclusiva conectados às rotas do servidor quando configuradas.
- Cadastro e login por e-mail e senha usando a autenticação do Supabase.
- Servidor com Node.js e Express.
- Banco de dados PostgreSQL pelo Supabase.
- Integração preparada para gerar cobranças Pix pelo Mercado Pago.
- Notificação de pagamento (Webhook) com validação de assinatura e consulta do pagamento na API do Mercado Pago.
- Acesso ao conteúdo conferido no servidor para a conta autenticada.
- Pagamentos desativados por padrão (`PAYMENTS_ENABLED=false`).
- O conteúdo do aplicativo ainda é inicial e precisa ser ampliado antes de ser vendido.

**Este projeto ainda não está pronto para receber dinheiro real.** Nenhuma credencial real está incluída. Só ative o pagamento depois de configurar os serviços, testar com credenciais de teste, validar o Webhook em uma URL HTTPS e testar todos os estados de pagamento.

## Como executar no computador

1. Instale o Node.js versão 20 ou superior.
2. Crie um projeto no Supabase e execute o arquivo `sql/schema.sql` no Editor SQL.
3. Ative a autenticação do Supabase por e-mail e senha.
4. Copie `.env.example` para `.env` e preencha as variáveis do ambiente. **Não compartilhe o arquivo `.env`.**
5. Execute `npm install` e depois `npm run dev`.
6. Abra `http://localhost:3000` no navegador.

## Configurações necessárias

- `SUPABASE_URL`: endereço do projeto Supabase.
- `SUPABASE_ANON_KEY`: chave pública usada pelo site.
- `SUPABASE_SERVICE_ROLE_KEY`: chave privada exclusiva do servidor; nunca a coloque no HTML.
- `MERCADOPAGO_ACCESS_TOKEN`: token privado do Mercado Pago; use primeiro as credenciais de teste.
- `MERCADOPAGO_WEBHOOK_SECRET`: segredo configurado no painel do Mercado Pago.
- `APP_BASE_URL`: endereço público HTTPS do site depois da publicação.
- `PAYMENTS_ENABLED`: mantenha `false` até concluir a configuração e os testes.
- `PRODUCT_PRICE`: preço definido no servidor; por padrão, R$ 19,90.

## Publicação com baixo custo

O arquivo `render.yaml` contém uma configuração inicial para publicar o servidor no Render. O Supabase fornece a autenticação e o banco de dados. Os planos gratuitos têm limites e podem pausar serviços; confira as condições atuais antes de colocar o site à venda.

## Lista de segurança antes de publicar

- Validar a assinatura do Webhook e consultar o pagamento diretamente no Mercado Pago.
- Conferir o pedido, o estado `approved` (aprovado), o método Pix, a moeda BRL e o valor exato.
- Manter a proteção contra pedidos e notificações duplicadas.
- Nunca liberar conteúdo com base apenas no redirecionamento do navegador ou em um comprovante enviado pelo comprador.
- Revisar login, privacidade, termos de uso, suporte e reembolsos.
- Se a pessoa responsável pelo projeto for menor de idade, configurar as contas de recebimento com um responsável legal, respeitando as regras do provedor.

## Arquivos do projeto

- `public/index.html`: site de vendas, conta, pagamento e área do produto.
- `server.js`: servidor, API e recebimento das notificações de pagamento.
- `sql/schema.sql`: estrutura e permissões do banco de dados.
- `.env.example`: modelo de configurações sem segredos reais.
- `render.yaml`: configuração inicial da hospedagem.
- `docs/landing-page-original-demo.html`: versão demonstrativa anterior da página, não conectada ao servidor.

## Observação importante

Os nomes técnicos de variáveis, rotas, bibliotecas e campos do banco permanecem em inglês quando isso é necessário para a integração funcionar corretamente. Os textos apresentados ao comprador e as instruções do projeto estão em português.
